package com.example.projectversion_00;

public class User_data {
   public String name,uname,phone,email,password;

   public User_data(){

   }
   public User_data(String name,String uname,String email,String phone,String password){

       this.name=name;
       this.email=email;
       this.uname=uname;
       this.phone=phone;
       this.password=password;

   }
}

